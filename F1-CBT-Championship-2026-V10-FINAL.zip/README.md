# CBT 1 — V10 FINAL
- CBT 1 branding; What-If removed.
- Animated, responsive laptop/mobile UI.
- Stronger red/cyan/violet UI accents while preserving team colours.
- Academic Admin uses only Physics, Mathematics and Chemistry scores; total is calculated automatically.
- Large all-drivers line graph plots every entered exam score by race, with ten distinct colours and a legend below.
- Existing Apps Script backend retained.
